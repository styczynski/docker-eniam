import sys

SOURCE_FILE = sys.argv[1]

valid_tags_data = dict() # name -> (count, freq)

with open(SOURCE_FILE) as src_file:
    for line in src_file:
        data = line.strip().split('\t')
        valid_tag = data[8]
        freq = int(data[3])
        prior = (0, 0)
        if valid_tag in valid_tags_data:
            prior = valid_tags_data[valid_tag]
        valid_tags_data[valid_tag] = (prior[0]+1, prior[1]+freq)

total_count = sum([entry[0] for _, entry in valid_tags_data.items()])
total_freq = sum([entry[1] for _, entry in valid_tags_data.items()])

keys = [
        ('OK', 'OK'),
        ('OK_CHANGECASE', 'OK_CHANGECASE'),
        ('GOODPOS', 'GOODPOS'),
        ('GOODPOS_NONINFL', 'GOODPOS_NONINFL'),
        ('GOODPOS_VERB', 'GOODPOS_VERB'),
        ('GOODPOS_CHANGECASE', 'GOODPOS_CHANGECASE'),
        ('GOODPOS_NONINFL_CHANGECASE', 'GOODPOS_NONINFL_CHANGECASE'),
        ('GOODPOS_VERB_CHANGECASE', 'GOODPOS_VERB_CHANGECASE'),
        ('LEMMA', 'LEMMA'),
        ('LEMMA_CHANGECASE', 'LEMMA_CHANGECASE'),
        ('FAIL', 'FAIL')
        ]

print('\\textbf{{{}}}'.format(SOURCE_FILE).replace('_', '\_'))
print()
print(
        """\\begin{tabular}{l|rrrr}
 & Liczba & Liczba & Procent & Procent\\\\
 & unikalnych & form & unikalnych & form\\\\
 & form & & form & \\\\
\\hline"""
        )
for (key, label) in keys:
    if key in valid_tags_data:
        print('{} & {} & {} & {:.4%} & {:.4%} \\\\'.format(label,
                                                   valid_tags_data[key][0],
                                                   valid_tags_data[key][1],
                                                   valid_tags_data[key][0]/total_count,
                                                   valid_tags_data[key][1]/total_freq).replace('%',
                                                       '\\%').replace('.', ',').replace('_', '\_'))
print(
        """\\hline
cały korpus & {} & {} & 100,0000\\% & 100,0000\\%\\\\
\\end{{tabular}}""".format(total_count, total_freq)
        )
print()
