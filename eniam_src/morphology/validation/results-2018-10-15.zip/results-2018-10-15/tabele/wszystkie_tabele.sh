#python3 maketable.py nazwa > tabela_nazwa.tex

python3 maketable.py nasze/walid_xCORR.tab > tabela_walid_xCORR.tex
python3 maketable.py nasze/walid_xCOMPD.tab > tabela_walid_xCOMPD.tex
python3 maketable.py nasze/walid_xCOMPD2.tab > tabela_walid_xCOMPD2.tex
python3 maketable.py nasze/walid_xDIAL.tab > tabela_walid_xDIAL.tex
python3 maketable.py nasze/walid_xPLTAN.tab > tabela_walid_xPLTAN.tex
python3 maketable.py nasze/walid_xTAGD.tab > tabela_walid_xTAGD.tex
python3 maketable.py sam/walid_xTAGD.tab > tabela_sam_walid_xTAGD.tex
python3 maketable.py sam/walid_xCORR_tkp.tab > tabela_sam_walid_xCORR_tkp.tex
python3 maketable.py sam/walid_xCOMPD.tab > tabela_sam_walid_xCOMPD.tex
python3 maketable.py sam/walid_xCOMPD2.tab > tabela_sam_walid_xCOMPD2.tex
python3 maketable.py sam/walid_xPLTAN.tab > tabela_sam_walid_xPLTAN.tex
python3 maketable.py sam/walid_xDIAL.tab > tabela_sam_walid_xDIAL.tex
python3 maketable.py tkp/walid_xTAGD.tab > tabela_tkp_walid_xTAGD.tex
python3 maketable.py tkp/walid_xCORR.tab > tabela_tkp_walid_xCORR.tex
python3 maketable.py tkp/walid_xCOMPD2.tab > tabela_tkp_walid_xCOMPD2.tex
python3 maketable.py tkp/walid_xPLTAN.tab > tabela_tkp_walid_xPLTAN.tex
python3 maketable.py tkp/walid_xDIAL.tab > tabela_tkp_walid_xDIAL.tex

echo '\documentclass{minimal} \usepackage[polish]{babel} \usepackage[T1]{fontenc} \usepackage[utf8]{inputenc} \begin{document}' > tabsy_start.tex
echo '\end{document}' > tabsy_end.tex
cat tabsy_start.tex tabela_* tabsy_end.tex > tabele.tex
pdflatex tabele.tex
