TRUTH_FILE=$1

awk '{print $1}' freqlist/$TRUTH_FILE | ./morphology > pred_$TRUTH_FILE
python3 compare.py freqlist/$TRUTH_FILE pred_$TRUTH_FILE > walid_$TRUTH_FILE 
