TRUTH_FILE=$1
awk  -v OFS='\t' '{print $1}' freqlist/$TRUTH_FILE > temp_forms #  | head -3000 dla CORR, 500 dla TAGD
takipi -old -force many -i temp_forms -o tkp/pred_$TRUTH_FILE
# dla CORR trzeba ręcznie przekształcić tagi chunk w jeden żeby działało
python3 compare_tkp.py freqlist/$TRUTH_FILE tkp/pred_$TRUTH_FILE > tkp/walid_$TRUTH_FILE 
