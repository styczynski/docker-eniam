TRUTH_FILE=$1
STAGE=$2

if [ $STAGE == '1' ]; then
	awk  -v OFS='\t' '{print $1}' freqlist/$TRUTH_FILE > temp_forms
	# sam ma niepjzetwarzalny output z %
	sed -i 's/%/proc/g' temp_forms
	iconv -c -f utf-8 -t latin2 temp_forms > temp_forms_conv
	rm sam34/wyniki.sam
fi

# po drodze trzeba uruchomić SAM

if [ $STAGE == '2' ]; then
	cp sam34/wyniki.sam sam/pred_$TRUTH_FILE
	python3 compare_sam.py freqlist/$TRUTH_FILE sam34/wyniki.sam > sam/walid_$TRUTH_FILE
fi
