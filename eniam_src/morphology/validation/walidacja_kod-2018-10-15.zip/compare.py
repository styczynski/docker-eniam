import sys

TRUTH_FILE = sys.argv[1]
PREDICTION_FILE = sys.argv[2]

with open(PREDICTION_FILE) as pred_file:
    prediction_blocks = pred_file.read().strip().split('\n\n')

with open(TRUTH_FILE) as truth_file:
    true_records = [rec.split('\t') for rec in truth_file.read().strip().split('\n')]

for sample_n, sample_record in enumerate(true_records):
    true_tags = sample_record[2].split(':')
    true_lemma = sample_record[1]
    prediction_pairs = [cells[:2]
                          for cells in
	                  [rec.split('\t') for rec in prediction_blocks[sample_n].split('\n')]]
    lemma_ok = False
    interp_ok = False
    case_changed = False
    pos_only = False
    for prediction_pair in prediction_pairs:
        if not prediction_pair[0] == true_lemma: # don't check if the lemma is incorrect
            if prediction_pair[0].lower() == true_lemma.lower() and not lemma_ok:
                case_changed = True
            else:
                continue
        lemma_ok = True
        if prediction_pair[0] == true_lemma: # may be necesarry to retoggle the case flag
            case_changed = False
        prediction_interp = prediction_pair[1]
        pred_tags = prediction_interp.split(':')
        if '|' in prediction_interp:
            options = prediction_interp.split('|')
            # Join the alternative interpretations.
            options = [option.split(':') for option in options]
            options = list(zip(*options))
            pred_tags = list([''.join([opt+'.' for opt in field]) for field in options])
        local_fail = False
        for tag_n, true_tag in enumerate(true_tags):
            if tag_n < len(pred_tags) and true_tag in pred_tags[tag_n].split('.'):
                continue
            if tag_n > 0:
                pos_only = True
            local_fail = True
            break
        if not local_fail:
            interp_ok = True
            pos_only = False
            if not case_changed:
                print('\t'.join(sample_record + ['OK']))
                break
    if lemma_ok and interp_ok and case_changed:
        print('\t'.join(sample_record + ['OK_CHANGECASE']))
    elif lemma_ok and pos_only and case_changed:
        print('\t'.join(sample_record + ['GOODPOS_CHANGECASE']))
    elif lemma_ok and pos_only and not case_changed:
        print('\t'.join(sample_record + ['GOODPOS']))
    elif lemma_ok and not interp_ok and not case_changed:
        print('\t'.join(sample_record + ['LEMMA']))
    elif lemma_ok and not interp_ok:
        print('\t'.join(sample_record + ['LEMMA_CHANGECASE']))
    elif not lemma_ok:
        print('\t'.join(sample_record + ['FAIL']))
