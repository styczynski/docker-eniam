import re, sys

TRUTH_FILE = sys.argv[1]
PREDICTION_FILE = sys.argv[2]

with open(PREDICTION_FILE, encoding='cp852') as pred_file:
    contents = pred_file.read().strip()
    # We need to handle tokens that SAM ignored and left with no interp.
    contents = re.sub('(?<!%)\n(?!%)', '}%\n', contents)
    prediction_blocks = [block.split('\n')
                         for block in re.split('}%\n(?![\\{])', contents)]

with open(TRUTH_FILE) as truth_file:
    true_records = [rec.split('\t') for rec in truth_file.read().strip().split('\n')]

for sample_n, sample_record in enumerate(true_records):
    true_tags = sample_record[2].split(':')
    true_lemma = sample_record[1]
    prediction_records = prediction_blocks[sample_n][2:]
    lemma_ok = False
    interp_ok = False
    case_changed = False
    pos_only = False
    verb_pos = False
    noninfl_pos = False
    for prediction_record in prediction_records:
        pred_lemma = re.search(' (.+?)(?=\()', prediction_record)
        if pred_lemma is None:
            continue
        else:
            pred_lemma = pred_lemma.group()[len(' < '):]

        if not pred_lemma == true_lemma: # don't check if the lemma is incorrect
            if pred_lemma.lower() == true_lemma.lower() and not lemma_ok:
                case_changed = True
            else:
                continue
        lemma_ok = True
        if pred_lemma == true_lemma: # may be necesarry to retoggle the case flag
            case_changed = False

        prediction_interp = re.search('(?<=\\w)\((.+?)\)', prediction_record).group()
        prediction_pos = prediction_interp.split(':')[0]
        if prediction_pos == '':
            prediction_pos = '_non-infl'
        elif prediction_pos[0] == 'A':
            prediction_pos = 'adj'
        elif prediction_pos[0] == 'K':
            prediction_pos = 'num'
        elif prediction_pos[0] == 'J':
            prediction_pos = 'adv'
        elif prediction_pos[0] == 'E':
            prediction_pos = 'prep'
        elif prediction_pos[0] in ['I', 'V', 'X']:
            prediction_pos = '_verb'
        else:
            prediction_pos = 'subst'

        if prediction_pos == true_tags[0]:
            pos_only = True
        if prediction_pos == '_verb' and true_tags[0] in ['fin', 'praet', 'bedzie', 'impt', 'winien', 'pact', 'ger', 'ppas']:
            pos_only = True
            verb_pos = True
        if prediction_pos == '_non-infl' and true_tags[0] in ['burk', 'adja', 'adjp', 'siebie', 'adjc', 'conj', 'interj', 'comp', 'qub', 'interp', 'xxx', 'ign']:
            pos_only = True
            noninfl_pos = True
    if lemma_ok and pos_only and case_changed:
        if verb_pos:
            print('\t'.join(sample_record + ['GOODPOS_VERB_CHANGECASE']))
        if noninfl_pos:
            print('\t'.join(sample_record + ['GOODPOS_NONINFL_CHANGECASE']))
        else:
            print('\t'.join(sample_record + ['GOODPOS_CHANGECASE']))
    elif lemma_ok and pos_only and not case_changed:
        if verb_pos:
            print('\t'.join(sample_record + ['GOODPOS_VERB']))
        if noninfl_pos:
            print('\t'.join(sample_record + ['GOODPOS_NONINFL']))
        else:
            print('\t'.join(sample_record + ['GOODPOS']))
    elif lemma_ok and not interp_ok and not case_changed:
        print('\t'.join(sample_record + ['LEMMA']))
    elif lemma_ok and not interp_ok:
        print('\t'.join(sample_record + ['LEMMA_CHANGECASE']))
    elif not lemma_ok:
        print('\t'.join(sample_record + ['FAIL']))
