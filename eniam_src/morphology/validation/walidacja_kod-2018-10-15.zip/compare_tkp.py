import sys
from lxml import etree

TRUTH_FILE = sys.argv[1]
PREDICTION_FILE = sys.argv[2]

with open(TRUTH_FILE) as truth_file:
    true_records = [rec.split('\t') for rec in truth_file.read().strip().split('\n')]

tree = etree.parse(PREDICTION_FILE)

tok_shift = 0 # needed because TOKIPI sometimes splits tokens
for tok_n, tok in enumerate(tree.iterfind('tok')):
    sample_record = true_records[tok_n-tok_shift]
    true_tags = sample_record[2].split(':')
    true_lemma = sample_record[1]
    true_orth = sample_record[0]
    if len(tok.find('orth').text) < len(true_orth):
        if tok.getnext().tag == 'ns': # pointer to original tokens needs to be bumped once
            tok_shift += 1
        continue
    lemma_ok = False
    interp_ok = False
    case_changed = False
    pos_only = False
    for lex in tok.iterfind('lex'):
        pred_lemma = lex.find('base').text
        if not pred_lemma == true_lemma: # don't check if the lemma is incorrect
            if pred_lemma.lower() == true_lemma.lower() and not lemma_ok:
                case_changed = True
            else:
                continue
        lemma_ok = True
        if pred_lemma == true_lemma: # may be necesarry to retoggle the case flag
            case_changed = False
        prediction_interp = lex.find('ctag').text
        pred_tags = prediction_interp.split(':')
        if '|' in prediction_interp:
            options = prediction_interp.split('|')
            # Join the alternative interpretations.
            options = [option.split(':') for option in options]
            options = list(zip(*options))
            pred_tags = list([''.join([opt+'.' for opt in field]) for field in options])
        local_fail = False
        for tag_n, true_tag in enumerate(true_tags):
            if tag_n < len(pred_tags) and true_tag in pred_tags[tag_n].split('.'):
                continue
            if tag_n > 0:
                pos_only = True
            local_fail = True
            break
        if not local_fail:
            interp_ok = True
            pos_only = False
            if not case_changed:
                print('\t'.join(sample_record + ['OK']))
                break
    if lemma_ok and interp_ok and case_changed:
        print('\t'.join(sample_record + ['OK_CHANGECASE']))
    elif lemma_ok and pos_only and case_changed:
        print('\t'.join(sample_record + ['GOODPOS_CHANGECASE']))
    elif lemma_ok and pos_only and not case_changed:
        print('\t'.join(sample_record + ['GOODPOS']))
    elif lemma_ok and not interp_ok and not case_changed:
        print('\t'.join(sample_record + ['LEMMA']))
    elif lemma_ok and not interp_ok:
        print('\t'.join(sample_record + ['LEMMA_CHANGECASE']))
    elif not lemma_ok:
        print('\t'.join(sample_record + ['FAIL']))
