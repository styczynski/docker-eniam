python3 comptable.py nasze/walid_xTAGD.tab tkp/walid_xTAGD.tab sam/walid_xTAGD.tab > porównanie_xTAGD.tex
python3 comptable.py nasze/walid_xPLTAN.tab tkp/walid_xPLTAN.tab sam/walid_xPLTAN.tab > porównanie_xPLTAN.tex
python3 comptable.py nasze/walid_xDIAL.tab tkp/walid_xDIAL.tab sam/walid_xDIAL.tab > porównanie_xDIAL.tex
python3 comptable.py nasze/walid_xCOMPD2.tab tkp/walid_xCOMPD2.tab sam/walid_xCOMPD2.tab > porównanie_xCOMPD2.tex
python3 comptable.py nasze/walid_xCORR.tab tkp/walid_xCORR.tab sam/walid_all_xCORR.tab > porównanie_xCORR.tex
