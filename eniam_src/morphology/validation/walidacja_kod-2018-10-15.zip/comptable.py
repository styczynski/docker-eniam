import sys

ENIAM_FILE = sys.argv[1]
TKP_FILE = sys.argv[2]
SAM_FILE = sys.argv[3]

def load_valid_data(filename):
    valid_tags_data = dict() # name -> (count, freq)

    with open(filename) as src_file:
        for line in src_file:
            data = line.strip().split('\t')
            valid_tag = data[8]
            freq = int(data[3])
            prior = (0, 0)
            if valid_tag in valid_tags_data:
                prior = valid_tags_data[valid_tag]
            valid_tags_data[valid_tag] = (prior[0]+1, prior[1]+freq)

    total_count = sum([entry[0] for _, entry in valid_tags_data.items()])
    total_freq = sum([entry[1] for _, entry in valid_tags_data.items()])
    return valid_tags_data, total_count, total_freq

eniam_data, total_count, total_freq = load_valid_data(ENIAM_FILE)
tkp_data, _, __ = load_valid_data(TKP_FILE)
sam_data, _, __ = load_valid_data(SAM_FILE)

keys = [
        ('OK', 'OK'),
        ('OK_CHANGECASE', 'OK_CHANGECASE'),
        ('GOODPOS', 'GOODPOS'),
        ('GOODPOS_NONINFL', 'GOODPOS_NONINFL'),
        ('GOODPOS_VERB', 'GOODPOS_VERB'),
        ('GOODPOS_CHANGECASE', 'GOODPOS_CHANGECASE'),
        ('GOODPOS_NONINFL_CHANGECASE', 'GOODPOS_NONINFL_CHANGECASE'),
        ('GOODPOS_VERB_CHANGECASE', 'GOODPOS_VERB_CHANGECASE'),
        ('LEMMA', 'LEMMA'),
        ('LEMMA_CHANGECASE', 'LEMMA_CHANGECASE'),
        ('FAIL', 'FAIL'),
        ('CRASH', 'CRASH')
        ]
if 'CORR' in SAM_FILE:
    sam_data['CRASH'] = (5, 6) # rejected records

print('\\textbf{{{}}}'.format(ENIAM_FILE).replace('_', '\_'))
print()
print(
        """\\begin{scriptsize}
\\begin{tabular}{l|rrr|rrr}
& \\multicolumn{3}{c|}{Procent unikalnych form} &
\\multicolumn{3}{c}{Procent form} \\\\
\\hline
& ENIAM & TaKIPI & SAM & ENIAM & TaKIPI & SAM \\\\
\\hline"""
        )
for (key, label) in keys:
    if not key in eniam_data:
        eniam_data[key] = (0, 0)
    if not key in tkp_data:
        tkp_data[key] = (0, 0)
    if not key in sam_data:
        sam_data[key] = (0, 0)
    print('{} & {:.2%} & {:.2%} & {:.2%} & {:.2%} & {:.2%} & {:.2%} \\\\'.format(label,
                                               eniam_data[key][0]/total_count,
                                               tkp_data[key][0]/total_count,
                                               sam_data[key][0]/total_count,
                                               eniam_data[key][1]/total_freq,
                                               tkp_data[key][1]/total_freq,
                                               sam_data[key][1]/total_freq).replace('%',
                                                   '\\%').replace('.', ',').replace('_', '\_'))
print(
"""\\end{tabular}
\\end{scriptsize}"""
        )
print()
