(*Należy oddzielnie uruchomić preprocesor i poczekać na załadowanie
  Program wypisuje tokeny należące kategorii do plików out/kat*
  a tokeny bez kategorii na stdout
*)

(*Dwie zmienne które zawężają ilość i długość tekstów jakie ma przetwarzać walidator, 
  przydatne przy ręcznej analizie wyników*)
let how_many = 1000000000
let shorter_than = 20000000


let path = "NKJP/data/NKJP-PodkorpusMilionowy-1.2/"

let time_from_of beg proc =
  proc ^ " done in " ^ (string_of_float (Unix.gettimeofday () -. beg)) ^ " seconds\n"

let option_to_string s =
  match s with 
  | None -> ""
  | Some x -> x

let port = 3258
let host = "localhost"

let get_sock_addr host_name port =
  let he = Unix.gethostbyname host_name in
  let addr = he.Unix.h_addr_list in
  Unix.ADDR_INET(addr.(0),port)

let toshiba_ub_path = "/home/wjaworski/Dokumenty/zasoby/"
let dell_path = "/home/ja/Pulpit/walidacja/"
    
let get_host_name () =
  let chan = Unix.open_process_in "uname -n" in
  input_line chan
    
let zasoby_path =
  match get_host_name () with
    "toshiba-UB" -> toshiba_ub_path
  | "dell" -> dell_path
  | s -> failwith ("unknown host: " ^ s)

let nkjp_path = zasoby_path ^ "NKJP/data/NKJP-PodkorpusMilionowy-1.2/" 

open NKJP
open PreTypes

let opt_to_int = function
  | Some x -> x
  | None -> (-1)
  
let opt_to_string = function
  | Some x -> x
  | None -> ""

open NKJP

let compare x y = 
  if x = y then 0 else
  if x < y then -1 else 1  
  
let sort_uniq: 'a list -> 'a list =
  let rec uniq = function
    | [] -> []
    | e1 :: e2 :: tl when e1 = e2 -> uniq (e1 :: tl)
    | hd :: tl -> hd :: uniq tl in
  fun s -> uniq (List.sort compare s)

let text_to_chars_simple s =
  (try UTF8.validate s with UTF8.Malformed_code -> failwith ("Invalid UTF8 string: " ^ s));
  let r = ref [] in
  UTF8.iter (fun c ->
    r := (UTF8.init 1 (fun _ -> c)) :: (!r)) s;
  List.rev (!r)

open List

(*a ma się zawierać w b*)
let diff a b = (*pierwsza lista to elementy z a których nie ma w b druga to które są*)
  let rec pom a b = 
    if a = [] then ([], []) else 
    if b = [] then (a, []) else
    let (a1, a2, a3) = hd a in
    let ok = List.fold_left (fun acc (b1, b2, b3) -> ((a1, a2, a3) = (b1, b2, b3)) || acc) false b in (* można przyśpieszyć*)
    let (r1, r2) = pom (tl a) b in
    if ok 
      then (r1, hd a::r2) 
      else (hd a::r1, r2) in
  pom (sort_uniq a) (sort_uniq b)


let rec diff2 a b =
  let rec pom a b = 
    if a = [] then ([], []) else 
    if b = [] then (a, []) else
    let (a1, a2, a3) = hd a in
    let ok = List.fold_left (fun acc (b1, b2, b3) -> String.sub a3 0 (min (String.length b3) (String.length a3)) = b3 || acc) false b in (* można przyśpieszyć*)
    let (r1, r2) = diff2 (tl a) b in
    if ok 
      then (r1, hd a::r2) 
      else (hd a::r1, r2) in
  pom (sort_uniq a) (sort_uniq b)
    
let rec diff3 a b = (*pomija długości*)
  let rec pom a b =
    if a = [] then ([], []) else 
    if b = [] then (a, []) else
    let (a1, _, a3) = hd a in
    let ok = List.fold_left (fun acc (b1, b2, b3) -> if ((a1, a3) = (b1, b3)) then b2 else acc) (-1) b in (* można przyśpieszyć*)
    let (r1, r2) = diff3 (tl a) b in
    if ok <> -1
      then (r1, (hd a, ok)::r2) 
      else (hd a::r1, r2) in
    pom (sort_uniq a) (sort_uniq b)

let special_chars = [".";"!";"?";"(";")";",";":";"...";"-"] (*; *)

let remove_special_chars l = 
  List.fold_left (fun acc ((a, b, c) as x) -> 
    if List.mem c special_chars then acc else x :: acc) [] l


let special_chars2 = [".";"!";"?";"(";")";",";":";"..."] (*; *)

let remove_special_chars2 l = 
  List.fold_left (fun acc ((a, b, c) as x) -> 
    if List.mem c special_chars2 then acc else x :: acc) [] l

let wypisz_l l = 
  List.iter (fun (a, b, c) -> 
      print_endline ((string_of_int a) ^ " " ^ (string_of_int b) ^ ": " ^ c)) l

let rec scal l = 
  match l with
  | (a1, a2, a3)::(b1, b2, b3)::x when a1 + a2 = b1 -> scal ((a1, a2 + b2, a3^b3) :: x)
  | (a1, a2, a3)::c::(b1, b2, b3)::x when a1 + a2 = b1 -> c::scal ((a1, a2 + b2, a3^b3) :: x)
  | x::a -> x::scal a
  | x -> x

let rec toscal2 l = 
  match l with 
  | (a1, a2, a3)::x -> (a1, a2, a3, a3) :: toscal2 x
  | [] -> [] 

let rec scal2 l = 
  match l with
  | (a1, a2, a3, a4)::(b1, b2, b3, b4)::x when a1 + a2 = b1 -> scal2 ((a1, a2 + b2, a3^b3, a4 ^ "|" ^ b4) :: x)
  | (a1, a2, a3, a4)::c::(b1, b2, b3, b4)::x when a1 + a2 = b1 -> c::scal2 ((a1, a2 + b2, a3^b3, a4 ^ "|" ^ b4) :: x)
  | (a1, a2, a3, a4)::x -> (a1, a2, a3, a4)::scal2 x
  | [] -> []


module StringMap = Map.Make(String)

exception PreError;;

let _ =
  let pre_in, pre_out = Unix.open_connection (get_sock_addr host port) in
  
  let send query =
    Printf.fprintf pre_out "%s\n%!" query;
    let paths, msg, pre_time = (Marshal.from_channel pre_in : 
        ((int * int * PreTypes.token_record) list * int) * string * float) in
    if msg <> "" 
    then 
      let _ = raise PreError in
      let _ = Printf.printf "query: %s\nBłąd: %s\n" query msg in
      failwith "pre zwraca błąd przy wysyłaniu zapytania"
    else
      (paths, msg, pre_time) in

  let smap1 = ref StringMap.empty in
  let smap2 = ref StringMap.empty in
  let smap3 = ref StringMap.empty in
  let smap4 = ref StringMap.empty in
  let smap5 = ref StringMap.empty in
  
  let cnt = ref 0 in

  let process_abs x id_source = 
    (*Wygodniej analizować ręcznie krótkie teksty*)
    if !cnt > how_many then () else
    let _ = cnt := !cnt + 1 in
    
    if String.length (opt_to_string x.contents) > shorter_than then () else
    
    
(*    let _ = print_endline (id_source ^ "\n" ^ (opt_to_string x.contents)) in*)
   
    let contenst_len = List.length (text_to_chars_simple (opt_to_string x.contents)) in
    let pass = ref false in
(*    let _ = print_endline "aaaa" in*)
    let nkjp_segm_list = List.fold_left 
      (fun acc (y:NKJP.sentence) ->
        let sen_segm = List.fold_left 
          (fun acc (z:NKJP.segm) -> 
            let beg = opt_to_int z.pos in
            let len = opt_to_int z.length in
(*            print_endline ((string_of_int beg) ^ " " ^ (string_of_int len));*)
            let pom = Array.of_list (text_to_chars_simple (opt_to_string x.contents)) in
            let orth = ref "" in
            if len + beg - 1 > contenst_len then pass := true else
            for i = beg to beg + len - 1 do
(*              print_endline ((string_of_int i) ^ " vs: " ^ (string_of_int (Array.length pom)));*)
              orth := !orth ^ pom.(i)
              done;
            (beg, len, !orth) :: acc) 
          [] y.segments in
        sen_segm @ acc) [] x.sentences in    
(*    let _ = print_endline "bbbb" in*)
    
    if !pass then () else
    
    let ((q, _), _, _) = send (opt_to_string x.contents) in
      
    let pre_segm_list = List.fold_left
      (fun acc (_, _, (x:PreTypes.token_record)) ->
        let calclen = (x.len + 99) / 100 in
        let calcbeg = (x.beg - 100) / 100 in
        if x.orth = "" then acc else 
        
        (*
        (*Wypisywanie segmenacji zwróconej przez preprocesor, odkomentować, żeby zobaczyć jak wyglądała*)
        
        let reallen = String.length x.orth in
        print_endline ((string_of_int x.beg) ^ " " ^ (string_of_int x.len) ^ " |" ^ x.orth ^ "|");
        print_endline ((string_of_int reallen) ^ " " ^ (string_of_int calclen));
        if (reallen != calclen) then print_endline "aaaa";*)
        
          (calcbeg, calclen, x.orth) :: acc) [] q in
    
    let nkjp_segm_list = sort_uniq nkjp_segm_list in
    let pre_segm_list = sort_uniq pre_segm_list in
    
    
    (*xdiff to wszystkie tokeny z nkjp które nie występują 'po prostu' w tokenach z pre*) 
    let (xdiff, _) = diff nkjp_segm_list pre_segm_list in
    let xdiff = sort_uniq xdiff in (*sortuje*)
    
    
    let kat1 = ref [] in
    let kat2 = ref [] in
    let kat3 = ref [] in
    let kat32 = ref [] in
    
    
    (*kategoria1 - czy istnieje jakiś token z nkjp nie przecinajacy się z żadnym z pre*)
    let diff0 = 
      List.fold_left 
        (fun acc ((poc, a2, _) as a) -> 
          let kon = poc + a2 - 1 in
          let ok = List.fold_left              (*można przyśpieszyć*)
            (fun acc (b1, b2, _) -> 
              let b2 = b1 + b2 - 1 in
              if (poc <= b1 && b1 <= kon) || (poc <= b2 && b2 <= kon) 
               || (b1 <= poc && kon <= b2) 
                then true 
                else acc) false pre_segm_list in
          if ok then a::acc
          else (kat1 := a::!kat1; acc)) [] xdiff in
    
    if !kat1 <> [] then
      ((*
       print_endline "KAT1!!!!!!";
       print_endline (id_source ^ "\n" ^ (opt_to_string x.contents));
       *)
       List.iter (fun (a1, a2, a3) -> 
        smap1 := StringMap.add a3 ("'" ^ a3 ^ "'\n       " ^ id_source ^ "       \n" ^ (opt_to_string x.contents) ^ "\n       beg: " ^ (string_of_int a1) 
                                  ^ " len: " ^ (string_of_int a2) ^ "\n") !smap1) !kat1; 
       (*
       wypisz_l !kat1;
       print_endline "\nnkjp";
       wypisz_l nkjp_segm_list;
       print_endline "\npre";
       wypisz_l pre_segm_list;
       print_endline "_____________\n________________"*)
      ) else
    
          
    let diff0 = sort_uniq diff0 in
    
    
    
    (*kategoria 2 - czy po scaleniu pozostałych z nkjp tokenów się zgadają z pre*)
    let ydiff = scal (sort_uniq diff0) in
    let (ydiff, temp) = diff ydiff pre_segm_list in
    kat2 := scal2 (toscal2 (sort_uniq diff0));
    
    if temp <> [] then
      (
      (*
      print_endline "KAT2!!!!";
      print_endline (id_source ^ "\n" ^ (opt_to_string x.contents));*)
      List.iter (fun (_, _, a) ->
                 let x = List.fold_left (fun acc (_, _, x, y) -> if x = a then y else acc) "" !kat2 in
                 smap2 := StringMap.add (x ^ "->" ^ a) true (!smap2);
                 (*print_endline (x ^ "->" ^ a)*)) temp;
      (*
      print_endline "\nnkjp";
      wypisz_l nkjp_segm_list;
      print_endline "\npre";
      wypisz_l pre_segm_list;
      print_endline "_____________\n________________"*)
      ) else
    
    
    (*przypadek3 scalam pre*)
    
    
    (*usuwam specjalne wyrażnia*)
    let pre_segm_list2 = scal (sort_uniq (remove_special_chars pre_segm_list)) in
    let (zdiff, temp) = diff ydiff (sort_uniq pre_segm_list2) in
    kat3 := scal2 (toscal2 (sort_uniq (remove_special_chars pre_segm_list)));
    
    (*nie usuwam*)
    let pre_segm_list2 = scal (sort_uniq (pre_segm_list)) in
    let (zdiff, temp2) = diff zdiff (sort_uniq pre_segm_list2) in
    kat32 := scal2 (toscal2 (sort_uniq pre_segm_list));
    
    let kat3 = ref ((!kat3) @ (!kat32)) in
    let temp = temp @ temp2 in
    
    (*usuwam nie wszystkie*)
    let pre_segm_list2 = scal (sort_uniq (remove_special_chars2 pre_segm_list)) in
    let (zdiff, temp2) = diff zdiff (sort_uniq pre_segm_list2) in
    kat32 := scal2 (toscal2 (sort_uniq (remove_special_chars2 pre_segm_list)));
    
    let kat3 = ref ((!kat3) @ (!kat32)) in
    let temp = temp @ temp2 in
    
    let pre_segm_list2 = scal (sort_uniq (pre_segm_list)) in
    
    
    if temp <> [] then
      (
      (*
      print_endline "KAT3!!!!";
      print_endline (id_source ^ "\n" ^ (opt_to_string x.contents));*)
      List.iter (fun (_, _, a) ->
                 let x = List.fold_left (fun acc (_, _, x, y) -> if x = a then y else acc) "---brak---" !kat3 in
(*                 if x = "---brak---" then
                  (print_endline "dupaaaaa";
                   print_endline "temp: ";
                   wypisz_l temp;
                   print_endline "kat3: ";
                   List.iter( fun (_, _, c, d) -> print_endline (c ^ " " ^ d)) !kat3;
                   
                   failwith "aaa";
                   );*)
                 smap3 := StringMap.add (x ^ "->" ^ a) true (!smap3);
                 (*print_endline (x ^ "->" ^ a)*)) temp;
                 (*
      print_endline "\nnkjp";
      wypisz_l nkjp_segm_list;
      
      print_endline "\nnkjp2";
      wypisz_l ydiff;
      
      print_endline "\nkat3";
      List.iter (fun (_, _, x, y) -> print_endline x) !kat3;
      
      print_endline "\npre";
      wypisz_l pre_segm_list;
      print_endline "_____________\n________________";*)()
      ) else
    
    
    
    (*przypadek 4*)
    (*suma pre nie jest nadzbiorem tego co zostało*)
    
(*    print_endline ("\n" ^ (opt_to_string x.contents));*)
    
    let sumofpre = Array.make (1 + List.length (text_to_chars_simple (opt_to_string x.contents))) (" ") in
    let _ = List.iter 
      (fun (poc, _, s) -> (*
        print_endline s;
        wypisz_l pre_segm_list;*)
        let pom = Array.of_list (text_to_chars_simple s) in
        for i = 0 to Array.length pom - 1 do
(*          print_endline ((string_of_int (i+poc)) ^ " vs: " ^ (string_of_int (Array.length sumofpre)));
          print_endline ((string_of_int (i)) ^ " vs2: " ^ (string_of_int (Array.length pom)));*)
          if sumofpre.(i+poc) <> " " && sumofpre.(i+poc) <> pom.(i) && false (*!!!!!*)
            then (print_endline ("\n" ^ (opt_to_string x.contents));
                  wypisz_l pre_segm_list;
                  failwith "błąd segmentacji (na tym samym miejscu w tekście dwa różne znaki)");
          sumofpre.(i+poc) <- pom.(i)
          done;
        ) pre_segm_list in (*wypełnia tablice*)
    
    
    let zdiff = List.fold_left 
      (fun acc ((poc, _, s) as a) -> 
        let pom = Array.of_list (text_to_chars_simple s) in
        let ok = ref true in
        for i = 0 to Array.length pom - 1 do
          if sumofpre.(i+poc) <> pom.(i) then ((*print_endline (sumofpre.(i+poc) ^ "|vs|" ^ pom.(i));*) ok := false)
          done;
        if not !ok 
        then 
          ((*print_endline ("!!!!!!!1:" ^ s);*)
           let str = ref "" in
           for i = 0 to Array.length pom - 1 do
            str := !str ^ sumofpre.(i+poc)
            done;
           smap4 := StringMap.add (s ^ "->" ^ !str) true !smap4; 
           acc) 
        else ((*print_endline ("!!!!!!!0:" ^ s);*) a::acc)) [] ydiff in (*zawiera się w pre*)
    
    (*przypadek 5*)
    
    let (zdiff, kat5) = diff3 zdiff pre_segm_list2 in
    
    if kat5 <> [] then
      ((*
      print_endline "KAT5!!!!";
      print_endline (id_source ^ "\n" ^ (opt_to_string x.contents));
      print_endline "\nnkjp";
      wypisz_l nkjp_segm_list;
      print_endline "\npre";
      wypisz_l pre_segm_list;
      *)
      List.iter (fun ((_, len2, s), len) -> 
       (* print_endline ("prelen: " ^ (string_of_int len) ^ " nkjplen: " ^ (string_of_int len2) ^ " string: " ^ s);*)
        let sss = ("prelen: " ^ (string_of_int len) ^ " nkjplen: " ^ (string_of_int len2) ^ " string: " ^ s) in
        smap5 := StringMap.add sss true !smap5;
        ) kat5;
      (*
      print_endline "_____________\n________________"*)
      ) else
    (*
      przypadek1 (występuje w nkjp i ma puste przecięcie z pre ) : pod orth przypadku wpisywać: zdanie, beg, len, orth z nkjp
      
      przypadek2 (nkjp dzieli na kawałki a pre scala): klucz jest zamianą z tokenów na token scalony
      
      przypadek3 (analogicznie jak 2, scalam spójne przedziały z pre): klucz też jest zmianą
      
      przypadek4 (czy to co zostało w pre jest nadzbiorem tego co jest): 
        O'Goreck -> O Goreck nie jest
        
      przypadek5 nie zgadza się długość
      
      *)
   
   (*Wypisywanie*)
    if zdiff != [] then
      (
(*      print_endline ("plik: " ^ id_source);
      
      print_endline (opt_to_string x.contents);*)
      (*
      print_endline "\nxdiff:";
      let _ = wypisz_l xdiff in
      
      print_endline "\ndiff0:";
      let _ = wypisz_l diff0 in
      
      print_endline "\nydiff:";
      let _ = wypisz_l ydiff in
      *)
      print_endline "\ndiff:";
      let _ = wypisz_l zdiff in
          
      print_endline "\nnkjp:";
      let _ = List.iter (fun (a, b, c) -> 
        print_endline ((string_of_int a) ^ " " ^ (string_of_int b) ^ ": " ^ c)) nkjp_segm_list in
      
      print_endline "\npre:";
      let _ = List.iter (fun (a, b, c) -> 
        print_endline ((string_of_int a) ^ " " ^ (string_of_int b) ^ ": " ^ c)) pre_segm_list in
      
(*      print_endline "\npre2:";
      let _ = List.iter (fun (a, b, c) -> 
        print_endline ((string_of_int a) ^ " " ^ (string_of_int b) ^ ": " ^ c)) pre_segm_list2 in
  *)    
(*      print_endline (NKJP.string_of_abs x);*)
  
      print_endline "_____________";
      ) else 
    
    () in

  
  let _ = NKJP.fold_segm nkjp_path  ~source:[] ~channel:[] () 
    (fun acc (t:NKJP.text) -> 
      List.iter (fun (x:NKJP.abs) -> 
        try process_abs x t.id_source
        with PreError -> Printf.eprintf "walidator zwraca błąd\n";) t.abs;
(*      print_endline (string_of_text t); 
      print_endline "______"; *)
      ()) in
  
  (*Wypisywanie*)
  
  (*Wypisywanie*)
  let to_file file s = 
    let oc = open_out ("out/" ^ file) in
    Printf.fprintf oc "%s\n" s;  
    close_out oc in
  
  let s = "KAT1 tokeny z nkjp mająca pustą część wspólną z pre:\n" ^
    (StringMap.fold (fun _ b acc -> acc ^ b ^ "\n") !smap1 "") in
  to_file "kat1" s;
  
  let s = "KAT2 tokeny się zgadzają po scaleniu spójnych przedziałów z nkjp, nkjp->pre:\n" ^ 
    (StringMap.fold (fun a _ acc -> acc ^ a ^ "\n") !smap2 "") in
  to_file "kat2" s;

  let s = "KAT3 tokeny się zgadzają po scaleniu spójnych przedziałów z pre, pre->nkjp:\n" ^ 
    (StringMap.fold (fun a _ acc -> acc ^ a ^ "\n") !smap3 "") in
  to_file "kat3" s;

  let s = "KAT4: niektóre znaki w pre nie zgadzają się(brakuje) w porównaniu do nkjp, nkjp->pre:\n" ^ 
    (StringMap.fold (fun a _ acc -> acc ^ a ^ "\n") !smap4 "") in
  to_file "kat4" s;
  
  let s = "KAT5 nie zgadzające się długości tokenów, orth i beg pasuje:\n" ^ 
   (StringMap.fold (fun a _ acc -> acc ^ a ^ "\n") !smap5 "") in
  to_file "kat5" s;
  
  Printf.fprintf pre_out "\n%!";
  let _ = Unix.shutdown_connection pre_in in
  ()

