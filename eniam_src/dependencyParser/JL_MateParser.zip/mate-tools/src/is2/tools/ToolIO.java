/**
 * 
 */
package is2.tools;

import is2.data.SentenceData09;

/**
 * @author Bernd Bohnet, 27.10.2010
 * 
 * Interface to all tools
 */
public interface ToolIO {

	void readModel(); 
	
}
