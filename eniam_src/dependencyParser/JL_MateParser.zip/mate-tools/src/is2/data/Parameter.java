/**
 * 
 */
package is2.data;

/**
 * @author Dr. Bernd Bohnet, 23.12.2010
 * 
 * 
 */
public class Parameter {

}
