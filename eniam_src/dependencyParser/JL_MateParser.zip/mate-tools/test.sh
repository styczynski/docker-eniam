#!/bin/bash
if [ ! -d dist ]; then
  mkdir dist
fi
if [ ! -d include ]; then
  mkdir include
fi
ant build

java -jar dist/anna-3.5.jar -model examples/160622_Polish_MateParser.mdl -test < examples/test.csv
